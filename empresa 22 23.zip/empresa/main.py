from flask import Flask
from flask_restx import reqparse, abort, Api, Resource, fields
app = Flask(__name__)
api = Api(app,
          version='1.0',
          title='API dos Produtos de uma Empresa',
          description='Permite gerenciar os registros dos produtos de uma empresa',
          doc='/doc')

FUNCIONARIOS = [{'cpf': 1, 'nome': 'Ana', 'horas': 8, 'valor':45.78},
                {'cpf': 2, 'nome': 'Bruna', 'horas': 2, 'valor':60.00},
                {'cpf': 3, 'nome': 'Carlos', 'horas': 10, 'valor':38.99},
                {'cpf': 4, 'nome': 'Diogo', 'horas': 4, 'valor':45.78},
                {'cpf': 5, 'nome': 'Ester', 'horas': 5, 'valor':45.78}]

            


def aborta_se_o_produto_nao_existe(cpf):

    encontrei = False

    for funcionario in FUNCIONARIOS:
        if funcionario['cpf'] == int(cpf):
            encontrei = True
        if encontrei == False:
            # 404:Not Found
            abort(404, mensagem="O funcionário de cpf = {} não existe".format(cpf))


# Parse dos dados enviados na requisição no formato JSON:
parser = reqparse.RequestParser()
parser.add_argument('cpf', type=int, help='cpf')
parser.add_argument('nome', type=str, help='nome')
parser.add_argument('valor', type=float, help='valor da hora')
parser.add_argument('horas', type=float, help='horas trabalhadas')


campos_obrigatorios_para_atualizacao = api.model('Atualizaçao de Produto', {
    'cpf': fields.Integer(required=True, description='cpf'),
    'nome': fields.String(required=True, description='nome'),
    'valor': fields.Float(required=True, description='valor da hora'),
    'horas': fields.Integer(required=True, description='horas trabalhadas'),

})
campos_obrigatorios_para_insercao = api.model('Inserção de Produto', {
    'cpf': fields.Integer(required=False, readonly=True,
                         description='cpf'),
    'nome': fields.String(required=True, description='nome'),
    'valor': fields.Float(required=True, description='valor da hora'),
    'horas': fields.Integer(required=True, description='horas trabalhadas'),

})
# Produto:
# 1) Apresenta um único produto.
# 2) Remove um único produto.
# 3) Atualiza (substitui) um produto.


@api.route('/funcionarios/<cpf>')
@api.doc(params={'cpf': 'cpf'})
class Funcionario(Resource):
    @api.doc(responses={200: 'Funcionario retornado'})
    def get(self, cpf):
        aborta_se_o_produto_nao_existe(cpf)
        return FUNCIONARIOS[int(cpf)]

    @api.doc(responses={204: 'funcionario removido'})  # 204: No Content
    def delete(self, cpf):
        aborta_se_o_produto_nao_existe(cpf)
        del FUNCIONARIOS[int(cpf)]
        return '', 204
@api.doc(responses={200: 'funcionario substituído'})  # 200: OK
@api.expect(campos_obrigatorios_para_atualizacao)
def put(self, cpf):
    aborta_se_o_produto_nao_existe(cpf)
    args = parser.parse_args()
    for funcionario in FUNCIONARIOS:
        if funcionario['cpf'] == int(cpf):
            funcionario['cpf'] = args['cpf']
            funcionario['nome'] = args['nome']
            funcionario['valor'] = args['valor']
            funcionario['horas'] = args['horas']
            break
    return funcionario

# ListaProduto:
# 1) Apresenta a lista de produtos.
# 2) Insere um novo produto.


@api.route('/funcionarios')
class ListaProduto(Resource):
    @api.doc(responses={200: 'funcionarios retornados'})
    def get(self):
        return FUNCIONARIOS
    @api.doc(responses={201: 'funcionario inserido'})  # 201: Created
    @api.expect(campos_obrigatorios_para_insercao)
    def post(self):
        args = parser.parse_args()
        cpf = 0
        for funcionario in FUNCIONARIOS:
            if int(funcionario['cpf']) > cpf:
                cpf = int(funcionario['cpf'])
        cpf = cpf + 1
        funcionario = {'cpf': cpf, 'nome': args['nome'], 'valor': args['valor'], 'horas': args['horas']}
        FUNCIONARIOS.append(funcionario)
        return funcionario, 201
if __name__ == '__main__':
    app.run(debug=True)

